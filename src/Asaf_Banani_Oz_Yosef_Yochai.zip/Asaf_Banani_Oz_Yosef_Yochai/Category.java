package Asaf_Banani_Oz_Yosef_Yochai;

public enum Category {
    KIDS, ELECTRONICS, OFFICE, CLOTHING
}
