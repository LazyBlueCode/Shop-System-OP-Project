package Asaf_Banani_Oz_Yosef_Yochai;

import java.util.Scanner;

//Name of presenters = ASAF BANANI 211961933, OZ YOSEF YOCHAI 213263262
//Lecturer: Eyal Haizenshtein

public class Main {
    private static Scanner sc = new Scanner(System.in);
    private static Market market = new Market();

    public static void main(String[] args) {

        menu();


    }
    public static String InputString() {
        boolean validInput = false;
        String res = null;
        while (!validInput) {
            res = sc.nextLine();

            // Check if input contains digits
            if (res.matches(".*\\d.*")) {
                System.out.print("Invalid input. Please enter a string without digits: ");
            }
            else {
                validInput = true;
            }
        }
        return res;
    }
    public static void menu() {
//        InterShop array_handler = new MarketSketch();

        int choose = -1;
        String text = " 0. Exit \n 1. Add Seller \n 2. Add Buyer \n 3. Add Product for Seller"
                + "\n 4. Add Product for Buyer \n 5. Shopping Cart \n 6. Display All Buyers \n"
                + " 7. Display All Sellers";
        //for(int i = 0; i < 8; i++) {
        //System.out.println("Option "+ i + ":");

        //}
        System.out.println(text);
        System.out.print("Enter option: ");
        choose = sc.nextInt();
        sc.nextLine();
        String name;
        String password;
        String city;
        String country;
        String address;
        while(choose != 0) {
            if (choose < 0 || choose > 7) {
                System.out.println("Invalid input choose again: ");
            }
            else if(choose == 1) {
                System.out.print("Add Name of seller: ");
                name = InputString();
                System.out.print("Add Name of password: ");
                password = sc.nextLine();
                while(!(market.AddSeller(name,password))||name==null || password==null) {
                    System.out.print("Name Taken, Add Name of seller: ");
                    name = InputString();
                    System.out.print("Password: ");
                    password = sc.nextLine();
                }
                System.out.println("Added new seller.");
            }
            else if(choose == 2) {
                System.out.print("Add Name of buyer: ");
                name = InputString();
                System.out.print("Add Name of password: ");
                password = sc.nextLine();
                while (password==null){
                    System.out.print("Enter valid password: ");
                    password = sc.nextLine();
                }
                System.out.print("Add Name of city: ");
                city = InputString();
                while (city==null){
                    System.out.print("Enter valid city: ");
                    city = InputString();
                }
                System.out.print("Add Name of country: ");
                country = InputString();
                while (country==null){
                    System.out.print("Enter valid country: ");
                    country = InputString();
                }
                System.out.print("Add Name of address: ");
                address = sc.nextLine();
                while (address==null){
                    System.out.print("Enter valid address: ");
                    address = sc.nextLine();
                }
                while(!(market.AddBuyer(name,password,new Adress(address,city,country)))||name==null) {
                    System.out.print("Name Taken, Add Name of buyer: ");
                    name = InputString();
                }
                System.out.println("Added new buyer.");
            }
            else if(choose == 3) {
                System.out.print(market.SellersList());
                System.out.print("Choose seller: ");
                name = InputString();
                System.out.print("Add product name for sale: ");
                String itemName = sc.nextLine();
                System.out.print("Add a price to the product you would like to sell: ");
                double price = sc.nextDouble();
                Product product = new Product(itemName,price);
                boolean res = market.AddProduct(name,product);
                while (!res)
                {
                    System.out.print("Enter a valid seller name: ");
                    name = InputString();
                    res = market.AddProduct(name,product);
                }
                System.out.println("Product Name: " + itemName + ", Price : $" + price + " Registered to seller: "
                        + name);
                //array_handler.AddItemToSeller();
            }
            else if(choose == 4) {
                if (market.getBuyersArray()[0] != null) {
                    System.out.print(market.BuyerList());
                    System.out.print("Choose Buyer to add Product: ");
                    String buyer = InputString();
                    System.out.print(market.SellersList());
                    System.out.print("Choose a Seller to buy from: ");
                    String seller = InputString();
                    while (!market.SellerExists(seller)) {
                        System.out.print("Seller not found, please choose again: ");
                        seller = InputString();
                    }
                    if (market.ProductListSellers(seller) == null) {
                        System.out.print("Seller has no items \n");
                    } else {
                        System.out.print(market.ProductListSellers(seller));
                        System.out.print("Choose Product to add to cart: ");
                        String itemName = sc.nextLine();
                        while (market.GetProduct(itemName, seller) == null) {
                            System.out.print("Product not found, try again?: (y/n) ");
                            if (sc.nextLine().toLowerCase().equals("y")) {
                                System.out.print("Choose Product to add to cart: ");
                                itemName = sc.nextLine();
                            } else if (sc.nextLine().toLowerCase().equals("n")) {
                                System.out.println("Returning to main menu.");
                                break;
                            }
                        }
                        if (market.GetProduct(itemName, seller) != null) {
                            market.AddProductToBuyer(buyer, (market.GetProduct(itemName, seller)));
                            System.out.println("Added product to buyer: " + buyer);
                        }
                    }

                }
                else{
                    System.out.println("There is No buyers yet, Returing to main menu");
                }
            }

            else if(choose == 5) {
                System.out.print(market.BuyerList());
                System.out.print("Choose Buyer to add Product: ");
                String buyer = InputString();

                System.out.println("Chosen Cart:\n" + market.findBuyer(buyer).getCart().ProductList());
                System.out.println("Sum: " + market.findBuyer(buyer).getCart().getSum()+"$ ,Want to checkout? (y/n)");
                if (sc.nextLine().toLowerCase().equals("y")){
                    market.checkout(market.findBuyer(buyer));
                    System.out.println("Checkout successful.");
                } else if (sc.nextLine().toLowerCase().equals("n")) {
                    System.out.println("Goodbye.");

                }
                //array_handler.shoppingCart();
            }
            else if(choose == 6) {
                if(market.getBuyersArray()[0] != null) {
                    System.out.println(market.BuyerInfo());
                }
                else{
                    System.out.println("There is no buyers yet.");
                }
            }

            else if(choose == 7) {
                if (market.getSellerArray()[0] != null) {
                    System.out.println(market.SellersInfo());
                }
                else{
                    System.out.println("There is no sellers yet.");
                }
            }
            choose = -1;
            System.out.println(text);
            System.out.print("Enter option: ");
            choose = sc.nextInt();
            sc.nextLine();

        }
        //}

    }


}