package Asaf_Banani_Oz_Yosef_Yochai;
// this is the manager class

public class Market {
    private Sellers[] sellerArray;
    private Buyers[] buyersArray;

    public Market() {
        sellerArray = new Sellers[10];
        buyersArray = new Buyers[10];
    }

    public Buyers[] getBuyersArray() {
        return buyersArray;
    }

    public Sellers[] getSellerArray() {
        return sellerArray;
    }

    public boolean SellerExists(String sellerName) {
        for (int i = 0; i < sellerArray.length; i++) {
            if(sellerArray[i]!=null){
                if (sellerArray[i].getName().equalsIgnoreCase(sellerName)) {
                    return true;
                }
            }
        }
        return false;
    }
    public Product GetProduct(String productName,String sellerName) {
        Cart cart;
        for (int i = 0; i < sellerArray.length; i++) {
            if (sellerArray[i] != null && sellerArray[i].getName().equalsIgnoreCase(sellerName)) {
                cart = sellerArray[i].getShop();
                return cart.findProduct(productName);
            }
        }
        return null;
    }
    public String ProductListSellers(String sellerName) {
        for (int i = 0; i < sellerArray.length; i++) {
            if(sellerArray[i] != null && sellerArray[i].getShop().getProducts()[0] !=null){
                if (sellerArray[i].getName().equalsIgnoreCase(sellerName)) {
                    return sellerArray[i].getShop().ProductList();
                }
            }
        }
        return null;
    }
    public String SellersList(){
        String res = "";
        for (int i = 0; i < sellerArray.length; i++) {
            if (sellerArray[i] != null) {
                res += (i+1)+") "+sellerArray[i].getName()+"\n";

            }
        }
        return res;
    }
    public String BuyerList(){
        String res = "";
        for (int i = 0; i < buyersArray.length; i++) {
            if (buyersArray[i] != null) {
                res += (i + 1) + ") " + buyersArray[i].getName() + "\n";

            }
        }
        return res;
    }
    public boolean AddProduct(String sellerName,Product product){
        for (int i = 0; i < sellerArray.length; i++) {
            if (sellerArray[i]!=null){
                if(sellerArray[i].getName().equalsIgnoreCase(sellerName)){
                    sellerArray[i].AddToShop(product);
                    return true;
                }
            }

        }
        return false;
    }
    public boolean AddSeller(String username, String password) {
        for (int i = 0; i < sellerArray.length; i++) {
            if(sellerArray[i]!=null) {
                if (sellerArray[i].getName().equalsIgnoreCase(username))
                    return false;
            }
        }
        Sellers new_seller = new Sellers(username, password, new Cart());
        for (int i = 0; i < this.sellerArray.length; i++) {
            if (this.sellerArray[i] == null) {
                this.sellerArray[i] = new_seller;
                return true;
            }
        }
        this.SellersArrayExpend();
        return this.AddSeller(username, password);
    }
    public void SellersArrayExpend(){
            if (this.sellerArray.length == 0) {
                this.sellerArray = new Sellers[10];
            } else {
                Sellers[] res = new Sellers[this.sellerArray.length * 2];
                for (int i = 0; i < this.sellerArray.length; i++) {
                    if (this.sellerArray[i] != null) {
                        res[i] = this.sellerArray[i];

                    }
                }
                this.sellerArray = res;
            }
        }

    public boolean AddBuyer(String username, String password,Adress adress) {
        for (int i = 0; i < this.buyersArray.length; i++) {
            if(buyersArray[i]!=null){
                if (this.buyersArray[i].getName().equalsIgnoreCase(username))
                    return false;
            }

        }
        Buyers new_buyer = new Buyers(username, password, new Cart(),adress);
        for(int i = 0; i < this.buyersArray.length; i++) {
            if (this.buyersArray[i] == null) {
                this.buyersArray[i] = new_buyer;
                return true;
            }
        }
        this.BuyerArrayExpend();
        return this.AddSeller(username, password);
    }
    public Buyers findBuyer(String username) {
        for (int i = 0; i < this.buyersArray.length; i++) {
            if (this.buyersArray[i].getName().equalsIgnoreCase(username)) {
                return buyersArray[i];
            }
        }
        return null;
    }
    public void BuyerArrayExpend(){
        if (this.buyersArray.length == 0) {
            this.buyersArray = new Buyers[10];
        } else {
            Buyers[] res = new Buyers[this.buyersArray.length * 2];
            for (int i = 0; i < this.buyersArray.length; i++) {
                res[i] = this.buyersArray[i];
            }
            this.buyersArray = res;
        }
    }
    public void checkout(Buyers buyer){
        buyer.AddToHistory(buyer.getCart());
        buyer.setCart(new Cart());
    }
    public void AddProductToBuyer(String buyer, Product product) {
        this.findBuyer(buyer).AddToBuyerCart(product);
    }
    public String BuyerInfo(){
        String res = "";
        for (int i = 0; i < this.buyersArray.length; i++) {
            if (this.buyersArray[i] != null) {
                res += "________________________\n";
                res +="Buyer "+ (i+1) + ":\n";
                res += "Name: " + this.buyersArray[i].getName()+"\n";
                res += "Country: " + this.buyersArray[i].getAdress().getCountry() +"\n";
                res += "City:  " + this.buyersArray[i].getAdress().getCity() +"\n";
                res += "Address:  " + this.buyersArray[i].getAdress().getAdress() + "\n";
                res += "Current cart: \n" + this.buyersArray[i].getCart().ProductList() +"\n";
                if(this.buyersArray[i].getCart().getSum() != 0.0)
                    res += "Left to pay: " + this.buyersArray[i].getCart().getSum() + "$\n";
                res += "History Carts: \n" + this.buyersArray[i].HistoryCart();
            }
        }
        return res;
    }

    public String SellersInfo() {
        String res = "";
        for (int i = 0; i < this.sellerArray.length; i++) {
            if (this.sellerArray[i] != null) {
                res += "________________________\n";
                res += "Seller " +  (i+1) +": " + this.sellerArray[i].getName() + "\n";
            //    res += "    Name: " + this.sellerArray[i].getName()+"\n";
                res += "    Shop: \n" + this.sellerArray[i].getShop().ProductList() + "\n";
            }
        }
        return res;
    }


}