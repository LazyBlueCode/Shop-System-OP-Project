package Asaf_Banani_Oz_Yosef_Yochai;

public class Sellers {
    private String name;
    private String password;
    private Cart shop;

    public Sellers(String name, String password, Cart cart) {
        this.name = name;
        this.password = password;
        this.shop = cart;

    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Cart getShop() {
        return shop;
    }

    public void setShop(Cart shop) {
        this.shop = shop;
    }

    public void AddToShop(Product prod) {
        this.shop.AddToCart(prod);
    }
}
